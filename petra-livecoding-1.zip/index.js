//NOMOR 1

/*
Buatlah sebuah algoritma untuk kasus berikut:
Seorang pengajar sedang memeriksa ujian mahasiswa dan akan memberikan desc nilai dari A-E dengan ketentuan sebagai berikut:
 - Nilai 80 - 100: A
 - Nilai 65 - 79: B
 - Nilai 50 - 64: C
 - Nilai 35 - 49: D
 - Nilai 0 - 34: E
​
 Tampilkan desc nilai dan nama siswa saat pengajar tersebut memasukkan nilai dan nama yang dia inginkan.
​
NOTED:
Jika nilai mahasiswa kurang dari 0 atau lebih dari 100 maka tampilkan 'Nilai Invalid'


//PSEUDOCODE

INPUT nilai AND nama siswa
IF nilai <= 100 && nilai >=80 THEN nilai = A
ELSE IF nilai <= 79 && nilai >=65 THEN nilai = B
ELSE IF nilai <= 64 && nilai >=50 THEN nilai = C
ELSE IF nilai <= 49 && nilai >=35 THEN nilai = D
ELSE IF nilai <= 34 && nilai >=0 THEN nilai = E
ELSE IF nilai > 100 && nilai < 0 THEN nilai = nilai invalid
SHOW desc nilai AND nama siswa



//NOMOR 2


---------------------
First Letter Grouping
---------------------
​
Diberikan sebuah variabel `name`. Buatlah sebuah script untuk menampilkan nama tersebut
berada di group ke-berapa, dengan aturan sebagai berikut:
- Jika huruf pertama dari `name` adalah a, b, c, d maka tampilkan 'Masuk group pertama'
- Jika huruf pertama dari `name` adalah e, f, g, h maka tampilkan 'Masuk group kedua'
- Selain itu tampilkan 'Masuk group terakhir'
​
Contoh:
- `name` = 'arief', output: 'Masuk group pertama'
- `name` = 'rinnina', output: 'Masuk group kedua'
- `name` = 'joshua', output: 'Masuk group terakhir'
- `name` = 'yusril', output: 'Masuk group terakhir'
​
*/

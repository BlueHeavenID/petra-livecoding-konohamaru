//nomor1

var count1 = 2 
console.log("LOOPING PERTAMA")
while (count1<21){
console.log(count1,"- I love coding")
count1+=2
}
console.log("LOOPING KEDUA")
while(count1>1){  
console.log(count1,"- I will become fullstack developer")
 count1-=2
}

//nomor2

console.log("LOOPING PERTAMA")
for(var count2 = 2; count2 < 21; count2++){
console.log(count2,"- I love coding")
}
console.log("LOOPING KEDUA")
for(var count2 = 20; count2 > 1; count2--){
console.log(count2,"- I will become fullstack developer")
}

//nomor3

/*var count3 = 1 
while (count3<101){
  
  if(count3%2 == 0){
console.log("GENAP")
}
else{
console.log("GANJIL")
}
count3++
}
*/

//GANJIL-GENAP
for(var count3 = 1; count3 < 101; count3++){

if (count3 % 2 == 0){
console.log("GENAP")
}
else{
  console.log("GANJIL")
}
}

//KELIPATAN
/*Buatlah 3 perulangan baru dari 1 - 100, dengan pertambahan counter sebesar 2, 5, dan 9.
Pada 3 perulangan baru ini periksa setiap angka counter:
Apabila bukan kelipatan yang ditentukan tidak perlu menuliskan apa-apa
Apabila angka counter adalah kelipatan 3 dengan pertambahan 2, kelipatan 6 dengan pertambahan 5, dan kelipatan 10 dengan pertambahan 9, tuliskan:
"3 kelipatan 3" dan seterusnya.
  }
*/
/*var count4 = 1 
while (count4<101){
  
  if(count4%3 == 0){
console.log(count4,"kelipatan 3")
}
count4 += 2
}*/
for(var count4 = 1; count4 < 101; count4+=2){
if (count4 % 3 == 0){
console.log(count4,"kelipatan 3")
}
}
for(var count4 = 1; count4 < 101; count4+=5){
if (count4 % 6 == 0){
console.log(count4,"kelipatan 6")
}
}
for(var count4 = 1; count4 < 101; count4+=9){
if (count4 % 10 == 0){
console.log(count4,"kelipatan 10")
}
}
  var kata = 'Hello World'
  var balik=''
  
  for (var i = kata.length-1; i >= 0; i--) {
    balik = balik + kata[i];
  }
  
  console.log(balik)
var name = 'hani';
var hurufPertama = name.substr(0, 1);

if(hurufPertama == 'a' ||hurufPertama == 'b' ||hurufPertama == 'c'|| hurufPertama == 'd'){
console.log('Masuk group pertama'); 
}
else if(hurufPertama == 'e' ||hurufPertama == 'f' ||hurufPertama == 'g'|| hurufPertama == 'h'){
console.log('Masuk group kedua'); 
}
else{
  console.log('Masuk group terakhir')
}
//nomor1

var rows1=5;
for(count=1;count<=rows1;count++){
  console.log("*")
}

//nomor2

var rows2=5;
for (count1=1;count1<=rows2;count1++){
console.log("*".repeat(rows2))
}

//nomor3
var rows3=5;
for (count2=1;count2<=rows3;count2++){
console.log("*".repeat(count2))
}
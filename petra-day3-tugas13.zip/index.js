
function xo(str) {
  // you can only write your code here!
  var strTotalX = 0
  var strTotalO = 0
  
  for (var i= str.length -1; i >= 0; i--){
    
    if (str[i] === 'x'){
      strTotalX += 1;
    } else if (str[i] === 'o'){
      strTotalO += 1;
    }
  }
  
  if (strTotalX === strTotalO){
    return true
  } else {
    return false
}
}

// TEST CASES
console.log(xo('xoxoxo')); // true
console.log(xo('oxooxo')); // false
console.log(xo('oxo')); // false
console.log(xo('xxxooo')); // true
console.log(xo('xoxooxxo')); // true